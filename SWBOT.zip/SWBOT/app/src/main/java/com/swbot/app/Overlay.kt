package com.swbot.app

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.hypot

/** Painel flutuante, mini mapa e tela de calibração. */
class Overlay(
    private val ctx: Context,
    private val prefs: Prefs,
    private val bot: Bot,
    private val onClose: () -> Unit
) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private val density = ctx.resources.displayMetrics.density

    private lateinit var panel: LinearLayout
    private lateinit var panelLp: WindowManager.LayoutParams
    private lateinit var statusTv: TextView
    private lateinit var radar: RadarView
    private lateinit var radarLp: WindowManager.LayoutParams
    private var calView: FrameLayout? = null
    private var radarOn = true
    private var alive = false

    private fun dp(v: Int) = (v * density).toInt()

    private fun type() = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    private fun smallBtn(text: String, onClick: (Button) -> Unit): Button {
        val b = Button(ctx)
        b.text = text
        b.textSize = 11f
        b.setTextColor(Color.WHITE)
        b.isAllCaps = false
        b.setPadding(dp(6), 0, dp(6), 0)
        val bg = GradientDrawable()
        bg.setColor(Color.rgb(133, 75, 208))
        bg.cornerRadius = dp(8).toFloat()
        b.background = bg
        val lp = LinearLayout.LayoutParams(dp(92), dp(34))
        lp.setMargins(0, dp(2), 0, dp(2))
        b.layoutParams = lp
        b.setOnClickListener { onClick(b) }
        return b
    }

    fun show() {
        alive = true
        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_SECURE // não aparece na captura do bot

        // ---- painel de botões ----
        panel = LinearLayout(ctx)
        panel.orientation = LinearLayout.VERTICAL
        val pbg = GradientDrawable()
        pbg.setColor(Color.argb(210, 33, 22, 55))
        pbg.cornerRadius = dp(10).toFloat()
        panel.background = pbg
        panel.setPadding(dp(4), dp(4), dp(4), dp(4))

        val handle = TextView(ctx)
        handle.text = "≡ SWBOT"
        handle.setTextColor(Color.rgb(198, 154, 255))
        handle.textSize = 12f
        handle.gravity = Gravity.CENTER
        handle.setPadding(0, dp(4), 0, dp(6))
        panel.addView(handle)

        panel.addView(smallBtn("● Gravar") { b ->
            if (bot.mode == Mode.RECORD) { bot.stopRecord(); b.text = "● Gravar" }
            else { bot.stop(); bot.startRecord(); b.text = "■ Salvar" }
        })
        panel.addView(smallBtn("▶ Rodar") { b ->
            if (bot.mode == Mode.PLAY) { bot.stop(); b.text = "▶ Rodar" }
            else { bot.startPlay(); if (bot.mode == Mode.PLAY) b.text = "■ Parar" }
        })
        panel.addView(smallBtn(if (prefs.autoAttack) "⚔ Ataque: ON" else "⚔ Ataque: OFF") { b ->
            prefs.autoAttack = !prefs.autoAttack
            b.text = if (prefs.autoAttack) "⚔ Ataque: ON" else "⚔ Ataque: OFF"
        })
        panel.addView(smallBtn("✥ Calibrar") { startCalibration() })
        panel.addView(smallBtn("🗺 Mapa") {
            radarOn = !radarOn
            radar.visibility = if (radarOn) View.VISIBLE else View.GONE
        })
        panel.addView(smallBtn("✕ Fechar") { onClose() })

        statusTv = TextView(ctx)
        statusTv.setTextColor(Color.rgb(197, 184, 216))
        statusTv.textSize = 10f
        statusTv.maxWidth = dp(92)
        panel.addView(statusTv)

        panelLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            type(), flags, PixelFormat.TRANSLUCENT
        )
        panelLp.gravity = Gravity.TOP or Gravity.START
        panelLp.x = dp(4)
        panelLp.y = dp(230)

        // arrastar pelo título
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = panelLp.x; oy = panelLp.y }
                MotionEvent.ACTION_MOVE -> {
                    panelLp.x = ox + (e.rawX - sx).toInt()
                    panelLp.y = oy + (e.rawY - sy).toInt()
                    wm.updateViewLayout(panel, panelLp)
                }
            }
            true
        }
        wm.addView(panel, panelLp)

        // ---- mini mapa (não captura toques) ----
        radar = RadarView(ctx, bot, prefs)
        radarLp = WindowManager.LayoutParams(
            dp(140), dp(140), type(),
            flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        radarLp.gravity = Gravity.TOP or Gravity.START
        radarLp.x = dp(4)
        radarLp.y = dp(80)
        wm.addView(radar, radarLp)

        tickUi()
    }

    private fun tickUi() {
        if (!alive) return
        statusTv.text = bot.status
        radar.invalidate()
        val ex = ArrayList<IntArray>()
        ex.add(intArrayOf(panelLp.x, panelLp.y, panelLp.x + panel.width, panelLp.y + panel.height))
        if (radarOn) ex.add(intArrayOf(radarLp.x, radarLp.y, radarLp.x + radarLp.width, radarLp.y + radarLp.height))
        bot.excl = ex
        ui.postDelayed({ tickUi() }, 250)
    }

    // ---------------- calibração ----------------
    private fun realSize(): IntArray {
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        return intArrayOf(dm.widthPixels, dm.heightPixels)
    }

    private fun startCalibration() {
        if (calView != null) return
        val steps = listOf(
            "1/4  Toque no CENTRO do seu personagem",
            "2/4  Toque no canto SUPERIOR ESQUERDO da área do jogo (onde aparece o chão)",
            "3/4  Toque no canto INFERIOR DIREITO da área do jogo",
            "4/4  Toque no CENTRO do quadrado de chão ao lado DIREITO do personagem"
        )
        var step = 0
        var cx = 0f; var cy = 0f; var x0 = 0f; var y0 = 0f; var x1 = 0f; var y1 = 0f
        val skills = ArrayList<PointF>()

        val root = FrameLayout(ctx)
        root.setBackgroundColor(Color.argb(90, 0, 0, 0))
        val msg = TextView(ctx)
        msg.setTextColor(Color.WHITE)
        msg.setBackgroundColor(Color.argb(220, 33, 22, 55))
        msg.textSize = 16f
        msg.gravity = Gravity.CENTER
        msg.setPadding(dp(12), dp(12), dp(12), dp(12))
        msg.text = steps[0]
        root.addView(msg, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP))

        val done = Button(ctx)
        done.text = "Concluir"
        done.visibility = View.GONE
        val dlp = FrameLayout.LayoutParams(dp(160), dp(48), Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        dlp.topMargin = dp(120)
        root.addView(done, dlp)

        val cancel = Button(ctx)
        cancel.text = "Cancelar"
        val clp = FrameLayout.LayoutParams(dp(120), dp(44), Gravity.TOP or Gravity.END)
        clp.topMargin = dp(70)
        root.addView(cancel, clp)

        fun finish(save: Boolean) {
            if (save) {
                prefs.centerX = cx; prefs.centerY = cy
                prefs.vx0 = x0; prefs.vy0 = y0; prefs.vx1 = x1; prefs.vy1 = y1
                prefs.tilePx = hypot(0.0 + tileDx, 0.0 + tileDy).toFloat().coerceAtLeast(8f)
                prefs.skills = skills
                bot.status = "Calibrado! tile=${prefs.tilePx.toInt()}px, habilidades=${skills.size}"
            }
            wm.removeView(root)
            calView = null
        }
        done.setOnClickListener { finish(true) }
        cancel.setOnClickListener { finish(false) }

        root.setOnTouchListener { _, e ->
            if (e.action != MotionEvent.ACTION_DOWN) return@setOnTouchListener true
            val x = e.rawX
            val y = e.rawY
            when (step) {
                0 -> { cx = x; cy = y }
                1 -> { x0 = x; y0 = y }
                2 -> { x1 = x; y1 = y }
                3 -> { tileDx = x - cx; tileDy = y - cy }
                else -> skills.add(PointF(x, y))
            }
            step++
            if (step < steps.size) msg.text = steps[step]
            else {
                msg.text = "Opcional: toque nos botões de habilidade (espadas) na ordem em que devem ser usados na caça. " +
                    "Já marcadas: ${skills.size}. Depois toque em Concluir."
                done.visibility = View.VISIBLE
            }
            true
        }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            type(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        wm.addView(root, lp)
        calView = root
    }

    private var tileDx = 0f
    private var tileDy = 0f

    fun hide() {
        alive = false
        ui.removeCallbacksAndMessages(null)
        try { wm.removeView(panel) } catch (e: Exception) {}
        try { wm.removeView(radar) } catch (e: Exception) {}
        calView?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        calView = null
    }
}
