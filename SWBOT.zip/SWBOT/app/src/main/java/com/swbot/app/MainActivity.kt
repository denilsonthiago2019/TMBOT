package com.swbot.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Tela principal: permissões, nome da rota, lista de rotas e botão de iniciar. */
class MainActivity : Activity() {
    private lateinit var prefs: Prefs
    private lateinit var info: TextView
    private lateinit var routesBox: LinearLayout
    private lateinit var nameEt: EditText
    private val REQ_CAPTURE = 42

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(text: String, click: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        b.setBackgroundColor(Color.rgb(133, 75, 208))
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48))
        lp.setMargins(0, dp(5), 0, dp(5))
        b.layoutParams = lp
        b.setOnClickListener { click() }
        return b
    }

    private fun label(text: String, size: Float = 14f, color: Int = Color.rgb(197, 184, 216)): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(color)
        t.setPadding(0, dp(6), 0, dp(6))
        return t
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(24), dp(16), dp(24))
        col.setBackgroundColor(Color.rgb(16, 13, 27))

        col.addView(label("SWBOT", 30f, Color.rgb(198, 154, 255)))
        col.addView(label("Bot para TibiaME (Android)"))

        info = label("")
        col.addView(info)

        col.addView(btn("1) Permitir flutuante (sobrepor apps)") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(btn("2) Ativar toques automáticos (Acessibilidade)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "Procure por SWBOT e ative", Toast.LENGTH_LONG).show()
        })

        col.addView(label("Nome da rota (gravar/rodar):"))
        nameEt = EditText(this)
        nameEt.inputType = InputType.TYPE_CLASS_TEXT
        nameEt.setTextColor(Color.WHITE)
        nameEt.setText(prefs.routeName)
        col.addView(nameEt)

        col.addView(btn("3) INICIAR (mostrar flutuante)") { startBot() })
        col.addView(btn("Parar bot") {
            startService(Intent(this, BotService::class.java).setAction(BotService.ACTION_STOP))
        })

        col.addView(label("Rotas salvas:", 16f, Color.rgb(198, 154, 255)))
        routesBox = LinearLayout(this)
        routesBox.orientation = LinearLayout.VERTICAL
        col.addView(routesBox)

        col.addView(label(
            "Como usar:\n" +
                "• Abra o TibiaME, toque em ✥ Calibrar no flutuante e siga os 4 passos.\n" +
                "• ● Gravar: ande tocando no chão. A estrela amarela que o jogo mostra vira o ponto da rota. Toque em ■ Salvar no fim.\n" +
                "• ▶ Rodar: comece no mesmo ponto onde gravou. O bot repete a rota, ataca o que se mexer e volta para a rota.\n" +
                "• 🗺 Mapa mostra a rota (roxo), seu caminho (azul), monstros (vermelho) e a estrela (amarelo)."
        ))

        val sv = ScrollView(this)
        sv.setBackgroundColor(Color.rgb(16, 13, 27))
        sv.addView(col)
        setContentView(sv)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun overlayOk() = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)

    private fun refresh() {
        info.text = "Flutuante: " + (if (overlayOk()) "OK" else "falta permitir") +
            "\nToques: " + (if (BotAccessibilityService.isRunning()) "OK" else "falta ativar") +
            "\nBot: " + (if (BotService.running) "rodando" else "parado") +
            "\nCalibração: " + (if (prefs.calibrated()) "feita" else "falta (use ✥ no flutuante)")
        routesBox.removeAllViews()
        for (n in prefs.routeNames()) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            val t = label("$n  (${prefs.loadRoute(n).size} pontos)", 15f, Color.WHITE)
            row.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val use = Button(this)
            use.text = "Usar"
            use.setOnClickListener { nameEt.setText(n); prefs.routeName = n }
            row.addView(use)
            val del = Button(this)
            del.text = "Apagar"
            del.setOnClickListener { prefs.deleteRoute(n); refresh() }
            row.addView(del)
            routesBox.addView(row)
        }
    }

    private fun startBot() {
        if (!overlayOk()) { Toast.makeText(this, "Permita o flutuante primeiro (passo 1)", Toast.LENGTH_LONG).show(); return }
        if (!BotAccessibilityService.isRunning()) {
            Toast.makeText(this, "Ative a Acessibilidade primeiro (passo 2)", Toast.LENGTH_LONG).show(); return
        }
        val name = nameEt.text.toString().trim().ifEmpty { "rota1" }
        prefs.routeName = name
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                val i = Intent(this, BotService::class.java)
                i.putExtra("code", resultCode)
                i.putExtra("data", data)
                startForegroundService(i)
                Toast.makeText(this, "Abra o TibiaME. O flutuante já está na tela.", Toast.LENGTH_LONG).show()
                moveTaskToBack(true)
            } else {
                Toast.makeText(this, "Captura de tela negada", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
