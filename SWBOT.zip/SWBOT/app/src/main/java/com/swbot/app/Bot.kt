package com.swbot.app

import android.graphics.PointF
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

enum class Mode { IDLE, RECORD, PLAY }

/**
 * Cérebro do bot. A cada ~200 ms:
 *  1) mede quanto o cenário andou (posição estimada do personagem),
 *  2) procura a estrela brilhante no chão (destino do toque no jogo),
 *  3) procura monstros se mexendo,
 *  4) grava a rota, ou segue a rota, ou ataca.
 */
class Bot(
    private val prefs: Prefs,
    private val grab: () -> Frame?
) {
    @Volatile var mode = Mode.IDLE
    @Volatile var excl: List<IntArray> = emptyList()   // áreas da tela a ignorar (nosso flutuante)

    // ---- estado para o mini mapa (somente leitura pela interface) ----
    @Volatile var posX = 0f
    @Volatile var posY = 0f
    @Volatile var route: List<PointF> = emptyList()
    @Volatile var trail: List<PointF> = emptyList()
    @Volatile var monsters: List<PointF> = emptyList() // px da tela
    @Volatile var star: PointF? = null                  // px da tela
    @Volatile var status = "Parado"
    @Volatile var routeIndex = 0

    private val routeW = ArrayList<PointF>()
    private val trailW = ArrayList<PointF>()
    private var idx = 0
    private var dir = 1

    private var prev: Frame? = null
    private var lastRaw: List<PointF> = emptyList()
    private var lastMoveTime = 0L
    private var lastTap = 0L
    private var lastTapX = 0f
    private var lastTapY = 0f
    private var noProgress = 0
    private var lastAtk = 0L
    private var lastSkill = 0L
    private var skillIdx = 0
    private var lastMonsterSeen = 0L

    @Volatile private var running = false
    private var thread: Thread? = null

    fun start() {
        if (running) return
        running = true
        thread = Thread {
            while (running) {
                try { tick() } catch (e: Exception) { status = "Erro: ${e.message}" }
                try { Thread.sleep(200) } catch (e: InterruptedException) { break }
            }
        }.also { it.isDaemon = true; it.start() }
    }

    fun shutdown() {
        running = false
        thread?.interrupt()
    }

    // ---------- comandos ----------
    fun startRecord() {
        routeW.clear(); trailW.clear()
        posX = 0f; posY = 0f
        routeW.add(PointF(0f, 0f))
        publish()
        mode = Mode.RECORD
        status = "Gravando: ande tocando no chão (a estrela deve aparecer)"
    }

    fun stopRecord(): Int {
        mode = Mode.IDLE
        val n = routeW.size
        if (n > 1) prefs.saveRoute(prefs.routeName, ArrayList(routeW))
        status = if (n > 1) "Rota '${prefs.routeName}' salva ($n pontos)" else "Rota vazia, nada salvo"
        return n
    }

    fun startPlay() {
        val r = prefs.loadRoute(prefs.routeName)
        if (r.size < 2) { status = "Sem rota '${prefs.routeName}'. Grave uma primeiro."; return }
        routeW.clear(); routeW.addAll(r)
        trailW.clear()
        posX = 0f; posY = 0f
        idx = 0; dir = 1; noProgress = 0
        lastMonsterSeen = 0
        publish()
        mode = Mode.PLAY
        status = "Seguindo '${prefs.routeName}' (comece no ponto onde gravou)"
    }

    fun stop() {
        mode = Mode.IDLE
        status = "Parado"
    }

    private fun publish() {
        route = ArrayList(routeW)
        trail = ArrayList(trailW)
        routeIndex = idx
    }

    // ---------- laço principal ----------
    private fun tick() {
        val f = grab() ?: return
        if (!prefs.calibrated()) { status = "Calibre primeiro (botão ✥)"; return }
        val now = System.currentTimeMillis()
        val rect = intArrayOf(
            max(0, (prefs.vx0 / Vision.SCALE).toInt()),
            max(0, (prefs.vy0 / Vision.SCALE).toInt()),
            min(f.sw, (prefs.vx1 / Vision.SCALE).toInt()),
            min(f.sh, (prefs.vy1 / Vision.SCALE).toInt())
        )
        val cx = prefs.centerX
        val cy = prefs.centerY
        val tile = prefs.tilePx
        val p = prev
        var shift: IntArray? = null
        if (p != null && p.sw == f.sw && p.sh == f.sh) shift = Vision.estimateShift(p, f, rect)
        if (shift != null) {
            posX -= shift[0] * Vision.SCALE.toFloat()
            posY -= shift[1] * Vision.SCALE.toFloat()
            if (shift[0] != 0 || shift[1] != 0) lastMoveTime = now
        }

        val st = Vision.findStar(f, rect, excl)
        star = st

        // monstros (precisa estar vendo o quadro anterior); só confirma se apareceu em 2 quadros seguidos
        var confirmed: List<PointF> = emptyList()
        if (p != null && p.sw == f.sw) {
            val raw = Vision.findMonsters(
                p, f, shift ?: intArrayOf(0, 0), rect, excl,
                PointF(cx / Vision.SCALE, cy / Vision.SCALE), tile / Vision.SCALE, prefs.sensitivity
            )
            confirmed = raw.filter { r -> lastRaw.any { hypot(it.x - r.x, it.y - r.y) < tile * 1.5f } }
            lastRaw = raw
        }
        monsters = confirmed
        prev = f

        when (mode) {
            Mode.RECORD -> doRecord(st, cx, cy, tile)
            Mode.PLAY -> doPlay(now, confirmed, cx, cy, tile)
            Mode.IDLE -> {}
        }
        publish()
    }

    private fun doRecord(st: PointF?, cx: Float, cy: Float, tile: Float) {
        // trilha por onde o personagem passou
        val lt = trailW.lastOrNull()
        if (lt == null || hypot(posX - lt.x, posY - lt.y) >= tile * 0.5f) trailW.add(PointF(posX, posY))
        if (st == null) return
        val wx = posX + (st.x - cx)
        val wy = posY + (st.y - cy)
        val last = routeW.last()
        if (hypot(wx - last.x, wy - last.y) >= tile * 0.6f) {
            routeW.add(PointF(wx, wy))
            status = "Gravando: ${routeW.size} pontos"
        }
    }

    private fun doPlay(now: Long, mons: List<PointF>, cx: Float, cy: Float, tile: Float) {
        val lt = trailW.lastOrNull()
        if (lt == null || hypot(posX - lt.x, posY - lt.y) >= tile * 0.5f) trailW.add(PointF(posX, posY))

        // ---- ataque automático ----
        if (prefs.autoAttack && mons.isNotEmpty()) {
            lastMonsterSeen = now
            status = "Atacando (${mons.size})"
            if (now - lastAtk > 700) {
                val m = mons.minByOrNull { hypot(it.x - cx, it.y - cy) }!!
                tap(m.x, m.y)
                lastAtk = now
            }
            val sk = prefs.skills
            if (sk.isNotEmpty() && now - lastSkill > 1300) {
                val s = sk[skillIdx % sk.size]
                tap(s.x, s.y)
                skillIdx++
                lastSkill = now
            }
            return
        }
        if (now - lastMonsterSeen < 1500) { status = "Terminando luta..."; return }

        // ---- seguir a rota ----
        if (routeW.isEmpty()) return
        idx = idx.coerceIn(0, routeW.size - 1)
        val t = routeW[idx]
        val dx = t.x - posX
        val dy = t.y - posY
        val dist = hypot(dx, dy)
        if (dist < tile * 0.8f) { advance(); return }
        status = "Indo ao ponto ${idx + 1}/${routeW.size}"
        val canTap = now - lastTap > 700 && (now - lastMoveTime > 500 || now - lastTap > 3000)
        if (!canTap) return
        val reachX = min(cx - prefs.vx0, prefs.vx1 - cx) - tile * 0.5f
        val reachY = min(cy - prefs.vy0, prefs.vy1 - cy) - tile * 0.5f
        var k = 1f
        if (kotlin.math.abs(dx) > 1f) k = min(k, reachX / kotlin.math.abs(dx))
        if (kotlin.math.abs(dy) > 1f) k = min(k, reachY / kotlin.math.abs(dy))
        // anda sempre pelo menos 1 quadrado para a direção certa
        val tx = cx + dx * k
        val ty = cy + dy * k
        if (hypot(posX - lastTapX, posY - lastTapY) < tile * 0.4f) noProgress++ else noProgress = 0
        lastTapX = posX; lastTapY = posY
        if (noProgress >= 4) { status = "Preso, pulando ponto"; noProgress = 0; advance(); return }
        tap(tx, ty)
        lastTap = now
    }

    private fun advance() {
        if (prefs.pingPong) {
            idx += dir
            if (idx >= routeW.size) { dir = -1; idx = max(0, routeW.size - 2) }
            if (idx < 0) { dir = 1; idx = min(1, routeW.size - 1) }
        } else {
            idx = (idx + 1) % routeW.size
        }
    }

    private fun tap(x: Float, y: Float) {
        BotAccessibilityService.instance?.tap(x, y)
    }
}
