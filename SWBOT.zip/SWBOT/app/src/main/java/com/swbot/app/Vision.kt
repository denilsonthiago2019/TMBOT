package com.swbot.app

import android.graphics.PointF
import android.media.Image
import kotlin.math.abs
import kotlin.math.hypot

/** Imagem reduzida (1 de cada 4 pixels) para análise rápida. */
class Frame(val sw: Int, val sh: Int, val px: IntArray) {
    val gray: IntArray by lazy {
        IntArray(px.size) {
            val p = px[it]
            (((p shr 16) and 255) + 2 * ((p shr 8) and 255) + (p and 255)) shr 2
        }
    }
}

object Vision {
    const val SCALE = 4

    fun fromImage(img: Image): Frame {
        val plane = img.planes[0]
        val buf = plane.buffer
        val rowStride = plane.rowStride
        val pixStride = plane.pixelStride
        val sw = img.width / SCALE
        val sh = img.height / SCALE
        val out = IntArray(sw * sh)
        for (y in 0 until sh) {
            val rowOff = y * SCALE * rowStride
            for (x in 0 until sw) {
                val o = rowOff + x * SCALE * pixStride
                val r = buf.get(o).toInt() and 255
                val g = buf.get(o + 1).toInt() and 255
                val b = buf.get(o + 2).toInt() and 255
                out[y * sw + x] = (r shl 16) or (g shl 8) or b
            }
        }
        return Frame(sw, sh, out)
    }

    private fun excluded(xs: Int, ys: Int, excl: List<IntArray>): Boolean {
        val x = xs * SCALE
        val y = ys * SCALE
        for (e in excl) if (x >= e[0] && x <= e[2] && y >= e[1] && y <= e[3]) return true
        return false
    }

    /**
     * Quanto o cenário andou entre dois quadros (em pixels reduzidos).
     * Se o conteúdo andou +dx, o personagem andou -dx.
     * Retorna null quando não dá para ter certeza.
     */
    fun estimateShift(prev: Frame, cur: Frame, rect: IntArray, maxShift: Int = 12): IntArray? {
        val p = 20
        val half = p / 2
        val xsList = ArrayList<Int>()
        val ysList = ArrayList<Int>()
        val g1 = cur.gray
        val g0 = prev.gray
        val sw = cur.sw
        val sh = cur.sh
        for (gy in 1..3) {
            for (gx in 1..3) {
                val cx = rect[0] + (rect[2] - rect[0]) * gx / 4
                val cy = rect[1] + (rect[3] - rect[1]) * gy / 4
                val x0 = cx - half
                val y0 = cy - half
                if (x0 - maxShift < 0 || y0 - maxShift < 0 ||
                    x0 + p + maxShift >= sw || y0 + p + maxShift >= sh
                ) continue
                // precisa ter textura, senão não dá para comparar
                var mean = 0
                var n = 0
                var y = y0
                while (y < y0 + p) {
                    var x = x0
                    while (x < x0 + p) { mean += g1[y * sw + x]; n++; x += 2 }
                    y += 2
                }
                mean /= n
                var dev = 0
                y = y0
                while (y < y0 + p) {
                    var x = x0
                    while (x < x0 + p) { dev += abs(g1[y * sw + x] - mean); x += 2 }
                    y += 2
                }
                if (dev / n < 6) continue

                var bestDx = 0
                var bestDy = 0
                var best = sad(g1, g0, sw, x0, y0, p, 0, 0, Int.MAX_VALUE)
                for (dy in -maxShift..maxShift) {
                    for (dx in -maxShift..maxShift) {
                        if (dx == 0 && dy == 0) continue
                        val s = sad(g1, g0, sw, x0, y0, p, dx, dy, best)
                        if (s < best) { best = s; bestDx = dx; bestDy = dy }
                    }
                }
                if (best / n > 14) continue
                xsList.add(bestDx)
                ysList.add(bestDy)
            }
        }
        if (xsList.size < 3) return null
        xsList.sort()
        ysList.sort()
        return intArrayOf(xsList[xsList.size / 2], ysList[ysList.size / 2])
    }

    private fun sad(cur: IntArray, prev: IntArray, sw: Int, x0: Int, y0: Int, p: Int,
                    dx: Int, dy: Int, limit: Int): Int {
        var s = 0
        var y = y0
        while (y < y0 + p) {
            var x = x0
            while (x < x0 + p) {
                s += abs(cur[y * sw + x] - prev[(y - dy) * sw + (x - dx)])
                x += 2
            }
            if (s >= limit) return s
            y += 2
        }
        return s
    }

    /** Procura a estrela amarela brilhante que o jogo mostra no chão (destino do toque). Retorna px da tela. */
    fun findStar(cur: Frame, rect: IntArray, excl: List<IntArray>): PointF? {
        var count = 0
        var sx = 0L
        var sy = 0L
        for (y in rect[1] until rect[3]) {
            for (x in rect[0] until rect[2]) {
                val p = cur.px[y * cur.sw + x]
                val r = (p shr 16) and 255
                val g = (p shr 8) and 255
                val b = p and 255
                if (r >= 235 && g >= 185 && b <= 120 && r - b >= 140) {
                    if (excluded(x, y, excl)) continue
                    count++
                    sx += x
                    sy += y
                }
            }
        }
        if (count < 5) return null
        return PointF(sx.toFloat() / count * SCALE + SCALE / 2f, sy.toFloat() / count * SCALE + SCALE / 2f)
    }

    /** Acha coisas se mexendo na área do jogo (monstros). Retorna pontos em px da tela. */
    fun findMonsters(
        prev: Frame, cur: Frame, shift: IntArray, rect: IntArray, excl: List<IntArray>,
        playerS: PointF, tileS: Float, sens: Int
    ): List<PointF> {
        val thr = 120 - sens
        val cell = 4
        val cw = (rect[2] - rect[0]) / cell
        val ch = (rect[3] - rect[1]) / cell
        if (cw <= 0 || ch <= 0) return emptyList()
        val cnt = IntArray(cw * ch)
        for (y in rect[1] until rect[3]) {
            val py = y - shift[1]
            if (py < 0 || py >= cur.sh) continue
            for (x in rect[0] until rect[2]) {
                val px0 = x - shift[0]
                if (px0 < 0 || px0 >= cur.sw) continue
                val a = cur.px[y * cur.sw + x]
                val b = prev.px[py * cur.sw + px0]
                val ar = (a shr 16) and 255
                val ag = (a shr 8) and 255
                val ab = a and 255
                if (ab > ar + 35 && ab >= ag - 10) continue // água
                val d = abs(ar - ((b shr 16) and 255)) + abs(ag - ((b shr 8) and 255)) + abs(ab - (b and 255))
                if (d > thr) {
                    if (excluded(x, y, excl)) continue
                    val cx = (x - rect[0]) / cell
                    val cy = (y - rect[1]) / cell
                    if (cx < cw && cy < ch) cnt[cy * cw + cx]++
                }
            }
        }
        val active = BooleanArray(cw * ch)
        for (cy in 0 until ch) {
            for (cx in 0 until cw) {
                if (cnt[cy * cw + cx] >= 5) {
                    val mx = rect[0] + cx * cell + cell / 2f
                    val my = rect[1] + cy * cell + cell / 2f
                    if (hypot(mx - playerS.x, my - playerS.y) > tileS * 0.9f) active[cy * cw + cx] = true
                }
            }
        }
        // agrupa células vizinhas
        val seen = BooleanArray(cw * ch)
        val out = ArrayList<PointF>()
        val stack = ArrayList<Int>()
        for (start in active.indices) {
            if (!active[start] || seen[start]) continue
            stack.clear()
            stack.add(start)
            seen[start] = true
            var n = 0
            var sx = 0f
            var sy = 0f
            while (stack.isNotEmpty()) {
                val c = stack.removeAt(stack.size - 1)
                val cx = c % cw
                val cy = c / cw
                n++
                sx += cx
                sy += cy
                for (ny in cy - 1..cy + 1) for (nx in cx - 1..cx + 1) {
                    if (nx < 0 || ny < 0 || nx >= cw || ny >= ch) continue
                    val ni = ny * cw + nx
                    if (active[ni] && !seen[ni]) { seen[ni] = true; stack.add(ni) }
                }
            }
            if (n in 2..40) {
                val mx = rect[0] + (sx / n) * cell + cell / 2f
                val my = rect[1] + (sy / n) * cell + cell / 2f
                out.add(PointF(mx * SCALE, my * SCALE))
            }
        }
        return out
    }
}
