package com.swbot.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

/**
 * Mini mapa: personagem no centro, rota gravada em roxo,
 * por onde já passou em azul, monstros em vermelho, estrela do chão em amarelo.
 */
class RadarView(ctx: Context, private val bot: Bot, private val prefs: Prefs) : View(ctx) {
    private val rangeTiles = 10f
    private val bg = Paint().apply { color = Color.argb(150, 10, 8, 20) }
    private val border = Paint().apply {
        color = Color.argb(220, 146, 85, 223); style = Paint.Style.STROKE; strokeWidth = 3f
    }
    private val grid = Paint().apply { color = Color.argb(60, 255, 255, 255); strokeWidth = 1f }
    private val routeLine = Paint().apply {
        color = Color.rgb(198, 154, 255); strokeWidth = 3f; isAntiAlias = true
    }
    private val routePt = Paint().apply { color = Color.rgb(198, 154, 255); isAntiAlias = true }
    private val target = Paint().apply { color = Color.rgb(117, 230, 160); isAntiAlias = true }
    private val trailP = Paint().apply { color = Color.rgb(80, 180, 255); isAntiAlias = true }
    private val monP = Paint().apply { color = Color.rgb(255, 60, 60); isAntiAlias = true }
    private val starP = Paint().apply { color = Color.rgb(255, 225, 60); isAntiAlias = true }
    private val me = Paint().apply { color = Color.WHITE; isAntiAlias = true }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawRoundRect(0f, 0f, w, h, 14f, 14f, bg)
        c.drawLine(w / 2, 0f, w / 2, h, grid)
        c.drawLine(0f, h / 2, w, h / 2, grid)
        val tile = prefs.tilePx
        if (tile <= 0f) { c.drawRoundRect(1f, 1f, w - 1, h - 1, 14f, 14f, border); return }
        val k = (w / 2) / rangeTiles / tile          // px da tela -> px do mini mapa
        val cx = w / 2
        val cy = h / 2
        val px = bot.posX
        val py = bot.posY

        val r = bot.route
        for (i in 0 until r.size - 1) {
            c.drawLine(cx + (r[i].x - px) * k, cy + (r[i].y - py) * k,
                cx + (r[i + 1].x - px) * k, cy + (r[i + 1].y - py) * k, routeLine)
        }
        for (i in r.indices) {
            val p = if (i == bot.routeIndex && bot.mode == Mode.PLAY) target else routePt
            c.drawCircle(cx + (r[i].x - px) * k, cy + (r[i].y - py) * k, if (p === target) 7f else 4f, p)
        }
        for (t in bot.trail) c.drawCircle(cx + (t.x - px) * k, cy + (t.y - py) * k, 2f, trailP)

        val pcx = prefs.centerX
        val pcy = prefs.centerY
        bot.star?.let { c.drawCircle(cx + (it.x - pcx) * k, cy + (it.y - pcy) * k, 6f, starP) }
        for (m in bot.monsters) c.drawCircle(cx + (m.x - pcx) * k, cy + (m.y - pcy) * k, 7f, monP)

        c.drawCircle(cx, cy, 6f, me)
        c.drawRoundRect(1f, 1f, w - 1, h - 1, 14f, 14f, border)
    }
}
