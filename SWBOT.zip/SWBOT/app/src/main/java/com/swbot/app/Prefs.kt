package com.swbot.app

import android.content.Context
import android.graphics.PointF
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Configurações, calibração e rotas gravadas (salvas no próprio aparelho). */
class Prefs(private val ctx: Context) {
    private val sp = ctx.getSharedPreferences("swbot", Context.MODE_PRIVATE)

    // Centro do personagem na tela (px). -1 = ainda não calibrado.
    var centerX: Float
        get() = sp.getFloat("cx", -1f)
        set(v) { sp.edit().putFloat("cx", v).apply() }
    var centerY: Float
        get() = sp.getFloat("cy", -1f)
        set(v) { sp.edit().putFloat("cy", v).apply() }

    // Área do jogo (canto superior esquerdo e inferior direito).
    var vx0: Float
        get() = sp.getFloat("vx0", -1f)
        set(v) { sp.edit().putFloat("vx0", v).apply() }
    var vy0: Float
        get() = sp.getFloat("vy0", -1f)
        set(v) { sp.edit().putFloat("vy0", v).apply() }
    var vx1: Float
        get() = sp.getFloat("vx1", -1f)
        set(v) { sp.edit().putFloat("vx1", v).apply() }
    var vy1: Float
        get() = sp.getFloat("vy1", -1f)
        set(v) { sp.edit().putFloat("vy1", v).apply() }

    // Tamanho de um quadrado do chão (tile) em pixels da tela.
    var tilePx: Float
        get() = sp.getFloat("tile", 0f)
        set(v) { sp.edit().putFloat("tile", v).apply() }

    // Botões de habilidade (ex.: espadas 1 e 2) tocados durante a caça: "x,y;x,y"
    var skills: List<PointF>
        get() = (sp.getString("skills", "") ?: "").split(";").mapNotNull {
            val p = it.split(",")
            if (p.size == 2) PointF(p[0].toFloat(), p[1].toFloat()) else null
        }
        set(v) { sp.edit().putString("skills", v.joinToString(";") { "${it.x},${it.y}" }).apply() }

    var autoAttack: Boolean
        get() = sp.getBoolean("atk", true)
        set(v) { sp.edit().putBoolean("atk", v).apply() }
    var pingPong: Boolean
        get() = sp.getBoolean("pingpong", false)
        set(v) { sp.edit().putBoolean("pingpong", v).apply() }
    var sensitivity: Int
        get() = sp.getInt("sens", 50)
        set(v) { sp.edit().putInt("sens", v).apply() }
    var routeName: String
        get() = sp.getString("routeName", "rota1") ?: "rota1"
        set(v) { sp.edit().putString("routeName", v).apply() }

    fun calibrated() = centerX >= 0 && vx1 > vx0 && vy1 > vy0 && tilePx > 0

    // ---------- Rotas ----------
    private fun routesFile() = File(ctx.filesDir, "rotas.json")

    private fun readAll(): JSONObject = try {
        JSONObject(routesFile().readText())
    } catch (e: Exception) {
        JSONObject()
    }

    fun routeNames(): List<String> {
        val o = readAll()
        val out = ArrayList<String>()
        val it = o.keys()
        while (it.hasNext()) out.add(it.next())
        out.sort()
        return out
    }

    fun saveRoute(name: String, pts: List<PointF>) {
        val o = readAll()
        val arr = JSONArray()
        for (p in pts) arr.put(JSONArray().put(p.x.toDouble()).put(p.y.toDouble()))
        o.put(name, arr)
        routesFile().writeText(o.toString())
    }

    fun loadRoute(name: String): List<PointF> {
        val arr = readAll().optJSONArray(name) ?: return emptyList()
        val out = ArrayList<PointF>()
        for (i in 0 until arr.length()) {
            val p = arr.getJSONArray(i)
            out.add(PointF(p.getDouble(0).toFloat(), p.getDouble(1).toFloat()))
        }
        return out
    }

    fun deleteRoute(name: String) {
        val o = readAll()
        o.remove(name)
        routesFile().writeText(o.toString())
    }
}
